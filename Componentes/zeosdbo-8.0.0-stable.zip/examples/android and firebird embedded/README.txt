This is a sample project demonstrating how to use Firebird 4.0 with Zeos on Android 64 Bits.

Getting started:
- Unpack the Firebird ARM64 files into the firebird folder.
- Grab a firebird.msg file from another distribution because it isn't generated automatically.
- Reset the libaries to system default if necessary.

The project was tested with Firebird 4.0. For other versions you might have to do some changes.

For an explanation see https://sourceforge.net/p/zeoslib/wiki/How%20to%20use%20Firebird%204.0%20RC1%20with%20Zeos%20on%20Android/