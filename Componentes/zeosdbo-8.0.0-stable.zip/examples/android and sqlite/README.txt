This is a sample project demonstrating how to use Firebird 4.0 with Zeos on Android 64 Bits.

Getting started:
- Download the current SQLite for Android file. It should be named sqlite-android-XXXXXXX.aar, where XXXXXXX is the version number.
- Add the zip extension to the file name.
- unpack the libsqliteX.so file from the jni\arm64-v8a folder in the zip file and place it in the sqlite directory.
- Reset the libaries of the project to system default if necessary.

The project was tested with SQLite 3.45.0. 

For a short explanation see https://sourceforge.net/p/zeoslib/wiki/How%20to%20use%20SQLite%20with%20Zeos%20on%20Android/