These files are a modified version of DelphiOTP.
DelphiOTP can be found at https://github.com/wendelb/DelphiOTP

The modified version can also be found at https://github.com/marsupilami79/DelphiOTP